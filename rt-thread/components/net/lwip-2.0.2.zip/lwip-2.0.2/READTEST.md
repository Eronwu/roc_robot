Porting lwip 2.0.2 running on RT-Thread.
The major jobs following RT-Thread Team. The RT-Thread team already port the lwip 2.0.0, so I only do some move code and test jobs.
I use the memory pools to test lwip 2.0.2, I use the iperf tool to test it about more than 20 hours, It is running normal.
I don't test it working on memory heap.
...
Good Luck.
by Hans.Huang 3/27/17 10:52 AM
huangxi_hans@163.com
