Some net apps for current version LwIP.

The RT-Thread develop team ported apps. It's easy to use it on finsh/msh.

- ping 
- tftp
